-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 24, 2023 at 12:37 PM
-- Server version: 5.5.20
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `fashion`
--

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE IF NOT EXISTS `content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `message` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`id`, `name`, `email`, `phone`, `message`) VALUES
(1, 'kyaw kyaw', 'kyawkyaw@gmail.com', '09123456789', 'Good news'),
(5, 'shwe yope', 'shwe@gmail.com', '09479945231', 'hope you will'),
(6, 'sports car news', 'aungaung@gmail.com', '09479945231', '5 star');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE IF NOT EXISTS `item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `img` varchar(100) NOT NULL,
  `prod_no` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`id`, `img`, `prod_no`, `price`) VALUES
(1, 'anis-m-WnVrO-DvxcE-unsplash.jpeg', 'Tee Pot', '20000MMK'),
(2, 'child cloths.jpeg', 'Clothe set', '20000MMK'),
(3, 'bottole.jpeg', 'bottle', '15000MMK'),
(4, 'team-fredi-8HRKoay8VJE-unsplash.jpeg', 'couple T shirt', '20000MMK'),
(5, 'running shoes.jpg', 'Running shoe', '35000MMK'),
(6, 'sneker.jpg', 'Sneker', '40000MMK'),
(7, 'woomenjeans.jpg', 'Jean for woomen', '18000MMK');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `productno` varchar(500) NOT NULL,
  `price` varchar(500) NOT NULL,
  `name` varchar(500) NOT NULL,
  `phone` varchar(500) NOT NULL,
  `adress` varchar(500) NOT NULL,
  `ordno` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `productno`, `price`, `name`, `phone`, `adress`, `ordno`) VALUES
(1, 'bottlole', '15000', 'kyaw kyaw maung', '09451789623', ' Yangon', 'ord34795'),
(6, 'child cloths', '20000', 'shwe yee', '0955423016', ' Manchester', 'ord27700'),
(7, 'Sneker', '40000MMK', 'aung thiha', '09445789071', ' Yangon', 'ord25545');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `confirm_password` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `username`, `email`, `password`, `confirm_password`, `phone`, `country`) VALUES
(1, 'Aung Thiha', 'aungthiha@gmail.com', 'passward123', 'passward123', '09445789071', 'Myanmar'),
(2, 'Shwe Yee', 'shewyee@gmail.com', 'shweyee123', 'shweyee123', '09774515891', 'Myanmar');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `password`) VALUES
('admin', '1234');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
